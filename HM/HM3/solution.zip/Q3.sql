-- 3. Write a query to show the employee_id and the salary of all employees in ascending order of salary. 
select EMPLOYEE_ID, SALARY
from employees order by SALARY asc