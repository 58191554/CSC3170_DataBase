-- 4. Write a query to calculate the maximum and minimum salary of all employees.
select  max(SALARY) as MAX_SALARY, min(SALARY) as MIN_SALARY
from employees